import App from "./App.svelte";
import "flowbite/dist/flowbite.css";

const app = new App({
  target: document.body,
});

export default app;
// main.js
